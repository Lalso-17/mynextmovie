import Foundation
import Testing
@testable import MyNextMovie

@MainActor struct TMDBTests {
    @Test func popularURLHasAPIKey() throws {
        #expect(tmdbPopularURL(apiKey: "test-key")?.absoluteString == "https://api.themoviedb.org/3/movie/popular?api_key=test-key")
    }
    @Test func searchUsesSearchEndpointAndTrimsText() throws {
        let url = try #require(tmdbSearchURL(query: " matrix ", genreId: noGenreId, apiKey: "key"))
        #expect(url.path == "/3/search/movie")
        #expect(URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.first(where: { $0.name == "query" })?.value == "matrix")
    }
    @Test func genreOnlyUsesDiscoverEndpoint() throws {
        let url = try #require(tmdbSearchURL(query: "", genreId: genreIdAnimation, apiKey: "key"))
        #expect(url.path == "/3/discover/movie")
    }
    @Test func decodesSnakeCaseMovieKeys() throws {
        let json = #"{"results":[{"id":603,"title":"The Matrix","overview":"","release_date":"1999-03-31","poster_path":null,"vote_average":8.2,"genre_ids":[28,878]}]}"#.data(using: .utf8)!
        let movie = try #require(decodeTMDBMovies(json).first)
        #expect(movie.releaseDate == "1999-03-31")
        #expect(movie.posterPath == nil)
        #expect(movie.genreIds == [28, 878])
    }
    @Test func unauthorizedResponseMentionsAPIKey() throws {
        let response = HTTPURLResponse(url: URL(string: "https://example.com")!, statusCode: 401, httpVersion: nil, headerFields: nil)!
        let error = #expect(throws: TMDBError.self) { try checkTMDBResponse(response) }
        #expect(error?.message.contains("API key") == true)
    }
}
