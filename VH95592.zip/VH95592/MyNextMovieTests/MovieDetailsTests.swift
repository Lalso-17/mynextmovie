import Foundation
import Testing
@testable import MyNextMovie

@MainActor struct MovieDetailsTests {
    @Test func runtimeFormatsHoursAndMinutes() {
        var details = emptyMovieDetails
        details = MovieDetails(id: 1, tagline: "", runtime: 136, credits: details.credits, videos: details.videos, releaseDates: details.releaseDates, watchProviders: details.watchProviders, recommendations: details.recommendations)
        #expect(formattedRuntime(details) == "2h 16m")
    }
    @Test func runtimeUnderHourShowsMinutes() {
        let details = MovieDetails(id: 1, tagline: "", runtime: 45, credits: emptyMovieDetails.credits, videos: emptyMovieDetails.videos, releaseDates: emptyMovieDetails.releaseDates, watchProviders: emptyMovieDetails.watchProviders, recommendations: emptyMovieDetails.recommendations)
        #expect(formattedRuntime(details) == "45m")
    }
    @Test func unknownRuntimeIsEmpty() { #expect(formattedRuntime(emptyMovieDetails) == "") }
    @Test func directorsAreUnique() {
        let details = MovieDetails(id: 1, tagline: "", runtime: nil, credits: Credits(cast: [], crew: [CrewMember(id: 1, name: "Director A", job: "Director"), CrewMember(id: 1, name: "Director A", job: "Director")]), videos: VideoList(results: []), releaseDates: ReleaseDateList(results: []), watchProviders: WatchProviderList(results: [:]), recommendations: TMDBMoviePage(results: []))
        #expect(directorNames(details) == "Director A")
    }
    @Test func recentTheatricalReleaseCountsAsInCinemas() {
        let release = ReleaseDate(certification: "12", releaseDate: "2026-10-17T00:00:00.000Z", type: releaseTypeTheatrical)
        let details = MovieDetails(id: 1, tagline: "", runtime: nil, credits: emptyMovieDetails.credits, videos: emptyMovieDetails.videos, releaseDates: ReleaseDateList(results: [CountryReleaseDates(countryCode: "PL", releaseDates: [release])]), watchProviders: emptyMovieDetails.watchProviders, recommendations: emptyMovieDetails.recommendations)
        #expect(isInCinemas(details, regionCode: "PL", today: Date(timeIntervalSince1970: 1_793_923_200)))
    }
    @Test func digitalReleaseDoesNotCountAsInCinemas() {
        let release = ReleaseDate(certification: "12", releaseDate: "2026-11-01T00:00:00.000Z", type: 4)
        let details = MovieDetails(id: 1, tagline: "", runtime: nil, credits: emptyMovieDetails.credits, videos: emptyMovieDetails.videos, releaseDates: ReleaseDateList(results: [CountryReleaseDates(countryCode: "PL", releaseDates: [release])]), watchProviders: emptyMovieDetails.watchProviders, recommendations: emptyMovieDetails.recommendations)
        #expect(!isInCinemas(details, regionCode: "PL", today: Date(timeIntervalSince1970: 1_793_923_200)))
    }
    @Test func officialYoutubeTrailerIsFound() {
        let details = MovieDetails(id: 1, tagline: "", runtime: nil, credits: emptyMovieDetails.credits, videos: VideoList(results: [Video(key: "first", site: "YouTube", type: "Trailer", official: false), Video(key: "official", site: "YouTube", type: "Trailer", official: true)]), releaseDates: emptyMovieDetails.releaseDates, watchProviders: emptyMovieDetails.watchProviders, recommendations: emptyMovieDetails.recommendations)
        #expect(trailerKey(details) == "official")
    }
}
