import Foundation
import SwiftData
import Testing
@testable import MyNextMovie

@MainActor func makeTestContainer() throws -> ModelContainer {
    let configuration = ModelConfiguration(isStoredInMemoryOnly: true)
    return try ModelContainer(for: Schema(storedModelTypes), configurations: [configuration])
}

@MainActor struct SavedMovieTests {
    @Test func toggleSavesThenRemoves() throws {
        let container = try makeTestContainer(); let context = container.mainContext
        let movie = Movie(id: 10, title: "Test", overview: "", releaseDate: "2020-01-01", posterPath: nil, voteAverage: 7, genreIds: [28])
        toggleSavedMovie(context, movie, now: Date(timeIntervalSince1970: 1))
        #expect(isSavedMovie(context, movieId: movie.id))
        toggleSavedMovie(context, movie, now: Date(timeIntervalSince1970: 2))
        #expect(!isSavedMovie(context, movieId: movie.id))
    }
    @Test func savedMovieRoundTripsAllFields() throws {
        let container = try makeTestContainer(); let context = container.mainContext
        let movie = Movie(id: 11, title: "Saved", overview: "Overview", releaseDate: "2001-01-01", posterPath: "/p.jpg", voteAverage: 8.1, genreIds: [18, 80])
        toggleSavedMovie(context, movie)
        let saved = try #require(context.fetch(FetchDescriptor<SavedMovie>()).first)
        #expect(movieFromSaved(saved) == movie)
    }
}

@MainActor struct SearchHistoryTests {
    @Test func trimsAndMovesRepeatedSearchToTop() throws {
        let container = try makeTestContainer(); let context = container.mainContext
        recordSearch(context, query: " matrix ", now: Date(timeIntervalSince1970: 1))
        recordSearch(context, query: "alien", now: Date(timeIntervalSince1970: 2))
        recordSearch(context, query: "matrix", now: Date(timeIntervalSince1970: 3))
        #expect(recentSearches(context).map(\.query) == ["matrix", "alien"])
    }
    @Test func ignoresEmptySearch() throws {
        let container = try makeTestContainer(); let context = container.mainContext
        recordSearch(context, query: "  ")
        #expect(recentSearches(context).isEmpty)
    }
}

@MainActor struct ResponseCacheTests {
    @Test func storesAndReturnsCachedResponse() throws {
        let container = try makeTestContainer(); let context = container.mainContext
        let data = Data("cached".utf8)
        storeCachedResponse(context, key: "popular", data: data)
        #expect(cachedResponseData(context, key: "popular") == data)
    }
    @Test func fallsBackToCacheWhenOffline() async throws {
        let container = try makeTestContainer(); let context = container.mainContext
        let cached = Data("cached".utf8)
        storeCachedResponse(context, key: "popular", data: cached)
        let result = try await fetchWithCacheFallback(context, key: "popular") { throw NoConnection() }
        #expect(result == cached)
    }
}
