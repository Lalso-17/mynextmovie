import Testing
@testable import MyNextMovie

@MainActor struct MovieDetailViewModelTests {
    @Test func startsIdleWithEmptyDetails() {
        let model = MovieDetailViewModel(movieId: 603, loadDetails: { _ in emptyMovieDetails })
        #expect(model.state == .idle)
        #expect(model.details.credits.cast.isEmpty)
    }
    @Test func loadsDetailsForRequestedMovie() async {
        var requestedId = 0
        let model = MovieDetailViewModel(movieId: 603, loadDetails: { id in requestedId = id; return emptyMovieDetails })
        await model.loadIfNeeded()
        #expect(requestedId == 603)
        #expect(model.state == .loaded)
    }
    @Test func reportsLoadFailure() async {
        let model = MovieDetailViewModel(movieId: 603, loadDetails: { _ in throw NoConnection() })
        await model.load()
        #expect(model.state == .failed)
        #expect(model.errorMessage == "No connection")
    }
}
