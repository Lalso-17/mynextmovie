import Testing
@testable import MyNextMovie

@MainActor struct CinemaMapViewModelTests {
    @Test func startsWithCinemasSortedByName() {
        let model = CinemaMapViewModel(cinemas: wroclawCinemas, findUserLocation: { fallbackUserLocation })
        #expect(model.cinemas.map(\.name) == wroclawCinemas.map(\.name).sorted())
    }
    @Test func freshLocationSortsByDistance() async {
        let user = UserLocation(latitude: 51.0983, longitude: 17.0368, isKnown: true)
        let model = CinemaMapViewModel(cinemas: wroclawCinemas, findUserLocation: { user })
        await model.locateUser()
        #expect(model.userLocation.isKnown)
        #expect(model.cinemas[0].distanceInMeters <= model.cinemas[1].distanceInMeters)
    }
    @Test func togglesCinemaSelection() {
        let model = CinemaMapViewModel(cinemas: wroclawCinemas, findUserLocation: { fallbackUserLocation })
        model.toggleCinema("dcf"); #expect(model.selectedCinemaId == "dcf")
        model.toggleCinema("dcf"); #expect(model.selectedCinemaId == noCinemaSelected)
    }
}
