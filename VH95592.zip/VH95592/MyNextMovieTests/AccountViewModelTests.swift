import Testing
@testable import MyNextMovie

@MainActor struct AccountViewModelTests {
    @Test func startsSignedOut() {
        let service = AccountService(signedInEmail: { "" }, signIn: { email, _ in email }, signUp: { email, _ in email }, signOut: {})
        let model = AccountViewModel(account: service, syncSavedMovies: {}, clearSavedMovies: {})
        #expect(!model.isSignedIn)
    }
    @Test func trimsEmailAndSignsIn() async {
        let service = AccountService(signedInEmail: { "" }, signIn: { email, _ in email }, signUp: { email, _ in email }, signOut: {})
        let model = AccountViewModel(account: service, syncSavedMovies: {}, clearSavedMovies: {})
        model.email = "  test@example.com  "; model.password = "password"
        await model.signIn()
        #expect(model.signedInEmail == "test@example.com")
        #expect(model.password.isEmpty)
    }
}
