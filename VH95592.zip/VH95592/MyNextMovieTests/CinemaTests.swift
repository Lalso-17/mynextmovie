import Foundation
import Testing
@testable import MyNextMovie

@MainActor struct CinemaTests {
    @Test func cinemasAreSortedByDistance() {
        let location = UserLocation(latitude: 51.0983, longitude: 17.0368, isKnown: true)
        let sorted = cinemasSortedByDistance(wroclawCinemas, from: location)
        #expect(sorted.count == wroclawCinemas.count)
        #expect(sorted[0].distanceInMeters <= sorted[1].distanceInMeters)
    }
    @Test func phoneURLRemovesFormattingCharacters() {
        let cinema = Cinema(id: "x", name: "X", address: "", phoneNumber: "+48 (123) 456-789", website: "", latitude: 0, longitude: 0)
        #expect(phoneURL(cinema)?.absoluteString == "tel:+48123456789")
    }
    @Test func unknownDistanceIsEmpty() { #expect(formattedDistance(unknownDistance).isEmpty) }
}
