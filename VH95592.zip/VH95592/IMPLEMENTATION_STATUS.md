# Implementation status — My Next Movie

This archive contains a substantial implementation pass over the supplied starter project. It is **not yet a verified final submission**: the environment used to prepare it is Linux and does not include Xcode or the iOS SDK, so an iOS build and simulator tests could not be run.

## Included

- Labs 1–2: retained starter implementation and existing tests.
- Lab 3: TMDB popular/search/detail requests, HTTP error handling, detail decoding models, detail view model, trailer/cast/streaming/recommendation sections, and basic unit tests.
- Lab 4: SwiftData models, saved-movie button and Saved tab, search history storage/UI, response cache, cached fallback for popular movies and details, and storage tests.
- Lab 5: Supabase client/authentication, sign-in/account screens, cloud saved-movie model, three-stage synchronization, startup/foreground/pending-change sync hooks, and basic account tests.
- Lab 6: Wrocław cinema helpers, distance sorting, location lookup with a 10-second timeout, map/list screen, cinema details, MapKit walking/driving routes, Apple Maps handoff, Look Around preview, and theatrical-release cinema sheet.

## Before submission — required verification and remaining polish

1. Open `MyNextMovie.xcodeproj` in Xcode 27 or newer on macOS and resolve Swift Package dependencies.
2. Copy `Config/Secrets.xcconfig.example` to `Config/Secrets.xcconfig` and enter a valid TMDB API key, Supabase project URL, and Supabase anon key.
3. Apply the included Supabase migration and seed data using the instructions in `docs/lab5.md` (`supabase db push --include-seed`).
4. Build the app and run the complete test plan. Fix any SDK-version or Swift concurrency diagnostics surfaced by Xcode.
5. Verify live TMDB detail decoding, Supabase sign-up/sign-in and offline sync, location permission behavior, walking/driving routes, and Look Around availability on a real simulator/device.
6. Compare each test against the exact required test list in `docs/lab3.md`–`docs/lab6.md`; the added tests are representative, not the full instructor checklist.

## Validation performed in this environment

- All Swift source files pass `swiftc -frontend -parse` syntax parsing.
- The ZIP archive passes `unzip -t` integrity validation.
- A full iOS build, SwiftData macro type-check, Supabase package type-check, simulator run, and complete Swift Testing suite were not possible here.
