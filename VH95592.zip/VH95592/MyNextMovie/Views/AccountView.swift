import SwiftUI

struct AccountView: View {
    @Bindable var viewModel: AccountViewModel
    var body: some View {
        Form {
            Section("Signed in as") { Text(viewModel.signedInEmail) }
            Section("Saved movies") {
                switch viewModel.syncState {
                case .idle: Text("Not synced yet")
                case .loading: Label("Syncing with your account", systemImage: "arrow.triangle.2.circlepath"); ProgressView()
                case .loaded: Label("In sync with your account", systemImage: "checkmark.icloud").foregroundStyle(.green)
                case .failed: Text(viewModel.syncErrorMessage).foregroundStyle(.red); Button("Try again") { Task { await viewModel.syncSavedMovies() } }
                }
            }
            Section {
                Button("Sign Out", role: .destructive) { Task { await viewModel.signOut() } }
                Text("Your saved movies remain on your account and are removed from this device when you sign out.").font(.footnote).foregroundStyle(.secondary)
            }
        }.navigationTitle("Account")
    }
}
