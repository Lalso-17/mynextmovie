import SwiftUI
import SwiftData

struct SavedMoviesView: View {
    @Query(
        sort: \SavedMovie.savedAt,
        order: .reverse
    )
    private var savedMovies: [SavedMovie]

    let loadDetails: MovieDetailsLoader

    var body: some View {
        NavigationStack {
            Group {
                if savedMovies.isEmpty {
                    ContentUnavailableView(
                        "No saved movies",
                        systemImage: "bookmark",
                        description: Text(
                            "Save a movie from its details screen using the bookmark button."
                        )
                    )
                } else {
                    MovieGrid(
                        title: "Watch Later",
                        movies: moviesFromSaved(savedMovies)
                    )
                }
            }
            .navigationTitle("Saved")
            .navigationDestination(for: Movie.self) { movie in
                MovieDetailView(
                    movie: movie,
                    loadDetails: loadDetails
                )
            }
        }
    }
}

// MARK: - Save Movie Button

struct SaveMovieButton: View {
    let movie: Movie

    @Environment(\.modelContext)
    private var modelContext

    @Query
    private var savedCopies: [SavedMovie]

    init(movie: Movie) {
        self.movie = movie

        let id = movie.id

        _savedCopies = Query(
            filter: #Predicate<SavedMovie> {
                $0.movieId == id
            }
        )
    }

    var body: some View {
        Button {
            toggleSavedMovie(
                modelContext,
                movie,
                now: .now
            )
        } label: {
            Image(
                systemName: savedCopies.isEmpty
                    ? "bookmark"
                    : "bookmark.fill"
            )
        }
        .accessibilityLabel(
            savedCopies.isEmpty
                ? "Save movie"
                : "Remove saved movie"
        )
    }
}
