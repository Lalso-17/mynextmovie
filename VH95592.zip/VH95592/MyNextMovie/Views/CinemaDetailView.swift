import SwiftUI
import MapKit

struct CinemaDetailView: View {
    @State var viewModel: CinemaDetailViewModel
    @State private var lookAroundScene: MKLookAroundScene?
    var body: some View {
        List {
            Section {
                Map {
                    Marker(viewModel.cinema.name, coordinate: cinemaCoordinate(viewModel.cinema))
                    if viewModel.routeState == .loaded { MapPolyline(viewModel.route.polyline).stroke(.blue, lineWidth: 5) }
                }.frame(height: 220).listRowInsets(EdgeInsets())
            }
            Section("Address") {
                Text(viewModel.cinema.address)
                if viewModel.cinema.distanceInMeters != unknownDistance { Text(formattedDistance(viewModel.cinema.distanceInMeters)).foregroundStyle(.secondary) }
            }
            Section("Way There") {
                Picker("Travel mode", selection: $viewModel.travelMode) { Text("Walk").tag(TravelMode.walking); Text("Drive").tag(TravelMode.driving) }.pickerStyle(.segmented)
                if viewModel.routeState == .loaded { Text(viewModel.routeSummary(viewModel.route)) }
                else if viewModel.routeState == .failed { Text(viewModel.errorMessage).foregroundStyle(.secondary) }
                else if viewModel.routeState == .loading { ProgressView() }
            }
            Section("Directions in Maps") {
                Button { openCinemaInMaps(viewModel.cinema, travelMode: viewModel.travelMode) } label: { Label("Open in Apple Maps", systemImage: "map") }
                if let url = phoneURL(viewModel.cinema) { Link(destination: url) { Label(viewModel.cinema.phoneNumber, systemImage: "phone") } }
                if let url = websiteURL(viewModel.cinema), hasWebsite(viewModel.cinema) { Link("Cinema website", destination: url) }
            }
            if let lookAroundScene {
                Section("Look Around") { LookAroundPreview(initialScene: lookAroundScene).frame(height: 220) }
            }
        }
        .navigationTitle(viewModel.cinema.name).navigationBarTitleDisplayMode(.inline)
        .task(id: viewModel.travelMode) { await viewModel.loadRoute() }
        .task { lookAroundScene = await findLookAroundScene(viewModel.cinema) }
    }
}
