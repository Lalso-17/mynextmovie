import SwiftUI

struct SignInView: View {
    @Bindable var viewModel: AccountViewModel
    var body: some View {
        VStack(spacing: spacingLarge) {
            Spacer()
            Image(systemName: "film.stack").font(.system(size: 54)).foregroundStyle(.tint)
            Text("My Next Movie").font(.largeTitle.bold())
            Text("Sign in to keep your saved movies synced across devices.").multilineTextAlignment(.center).foregroundStyle(.secondary)
            TextField("Email", text: $viewModel.email).textContentType(.emailAddress).keyboardType(.emailAddress).textInputAutocapitalization(.never).autocorrectionDisabled().textFieldStyle(.roundedBorder)
            SecureField("Password", text: $viewModel.password).textContentType(.password).textFieldStyle(.roundedBorder).onSubmit { Task { await viewModel.signIn() } }
            Button("Sign In") { Task { await viewModel.signIn() } }.buttonStyle(.borderedProminent).disabled(!viewModel.canSignIn).frame(maxWidth: .infinity)
            Button("Create Account") { Task { await viewModel.signUp() } }.disabled(!viewModel.canSignUp)
            if viewModel.state == .loading { ProgressView() }
            if viewModel.state == .failed { Text(viewModel.errorMessage).foregroundStyle(.red).font(.footnote) }
            if viewModel.isWaitingForEmailConfirmation { Text("Check your email and follow the confirmation link before signing in.").font(.footnote).foregroundStyle(.secondary) }
            else { Text("Password must contain at least \(minimumPasswordLength) characters to create an account.").font(.footnote).foregroundStyle(.secondary) }
            Spacer()
        }.padding(28).frame(maxWidth: 440)
    }
}
