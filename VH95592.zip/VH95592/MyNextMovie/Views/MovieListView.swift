import SwiftUI
import SwiftData

private let gridMinimumColumnWidth: CGFloat = 150

struct MovieListView: View {
    @State private var viewModel: MovieListViewModel
    let loadDetails: MovieDetailsLoader

    init(
        viewModel: MovieListViewModel,
        loadDetails: @escaping MovieDetailsLoader = fetchMovieDetails
    ) {
        _viewModel = State(initialValue: viewModel)
        self.loadDetails = loadDetails
    }

    var body: some View {
        NavigationStack {
            content
                .navigationTitle("My Next Movie")
                .navigationDestination(for: Movie.self) { movie in
                    MovieDetailView(
                        movie: movie,
                        loadDetails: loadDetails
                    )
                }
        }
        .task {
            await viewModel.loadIfNeeded()
        }
    }

    @ViewBuilder
    private var content: some View {
        switch viewModel.state {
        case .idle, .loading:
            loadingGrid

        case .loaded:
            loadedGrid

        case .failed:
            ErrorView(
                title: "Could not load movies",
                message: viewModel.errorMessage
            ) {
                Task {
                    await viewModel.load()
                }
            }
        }
    }

    private var loadingGrid: some View {
        MovieGrid(title: "Popular", movies: sampleMovies)
            .redacted(reason: .placeholder)
            .allowsHitTesting(false)
    }

    @ViewBuilder
    private var loadedGrid: some View {
        if viewModel.movies.isEmpty {
            ContentUnavailableView(
                "No movies",
                systemImage: symbolNameMovies
            )
        } else {
            MovieGrid(
                title: "Popular",
                movies: viewModel.movies
            )
        }
    }
}

// MARK: - Shared Movie Grid

struct MovieGrid: View {
    let title: String
    let movies: [Movie]

    private let columns = [
        GridItem(
            .adaptive(minimum: gridMinimumColumnWidth),
            spacing: 16
        )
    ]

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.title2.bold())
                .padding(.horizontal)

            ScrollView {
                LazyVGrid(
                    columns: columns,
                    spacing: 16
                ) {
                    ForEach(movies) { movie in
                        MovieGridItem(movie: movie)
                    }
                }
                .padding(.horizontal)
                .padding(.bottom)
            }
        }
    }
}

// MARK: - Movie Grid Item

private struct MovieGridItem: View {
    let movie: Movie

    var body: some View {
        NavigationLink(value: movie) {
            MovieCardView(movie: movie)
        }
        .buttonStyle(.plain)
    }
}

#Preview {
    MovieListView(
        viewModel: MovieListViewModel(
            loadMovies: loadSampleMovies
        )
    )
    .modelContainer(
        for: storedModelTypes,
        inMemory: true
    )
}
