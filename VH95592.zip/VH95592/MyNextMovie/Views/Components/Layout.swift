import SwiftUI

// Spacing scale shared by every screen, in points.
let spacingTiny: CGFloat = 2
let spacingExtraSmall: CGFloat = 4
let spacingSmall: CGFloat = 8
let spacingMedium: CGFloat = 12
let spacingLarge: CGFloat = 16
let spacingExtraLarge: CGFloat = 24
let spacingHuge: CGFloat = 32

let posterCornerRadius: CGFloat = 12
let thumbnailCornerRadius: CGFloat = 6

// SF Symbols used outside the genre table.
let symbolNameMovies = "film"
let symbolNameSearch = "magnifyingglass"
let symbolNameError = "exclamationmark.triangle"
let symbolNameRatingStar = "star.fill"

let symbolNameCinema = "popcorn.fill"
let symbolNameLocationOff = "location.slash"
let symbolNameDirections = "arrow.triangle.turn.up.right.diamond.fill"
let symbolNamePhone = "phone.fill"
let symbolNameWebsite = "safari"
let symbolNameWalking = "figure.walk"
let symbolNameDriving = "car.fill"
let symbolNameDetails = "info.circle"
