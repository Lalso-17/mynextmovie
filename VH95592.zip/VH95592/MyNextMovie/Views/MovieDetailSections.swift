import SwiftUI

struct MovieDetailSections: View {
    let details: MovieDetails
    private var providers: CountryWatchProviders { watchProviders(details, regionCode: watchRegionCode) }
    var body: some View {
        VStack(alignment: .leading, spacing: spacingExtraLarge) {
            if let url = trailerURL(details) { Link(destination: url) { Label("Watch Trailer", systemImage: "play.rectangle.fill").font(.headline) } }
            if !details.credits.cast.isEmpty { castSection }
            if hasWatchProviders(providers) { providerSection }
            if !details.recommendations.results.isEmpty { recommendationsSection }
        }
    }
    private var castSection: some View {
        VStack(alignment: .leading, spacing: spacingSmall) {
            Text("Cast").font(.title3.bold())
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(alignment: .top, spacing: spacingMedium) {
                    ForEach(details.credits.cast.prefix(15)) { person in
                        VStack(alignment: .leading, spacing: 4) {
                            Group { if let url = profileURL(person) { AsyncImage(url: url) { image in image.resizable().scaledToFill() } placeholder: { Image(systemName: "person.fill").resizable().scaledToFit().padding(18) } } else { Image(systemName: "person.fill").resizable().scaledToFit().padding(18) } }
                                .frame(width: 92, height: 92).background(.quaternary).clipShape(Circle())
                            Text(person.name).font(.caption.bold()).lineLimit(2)
                            Text(person.character).font(.caption2).foregroundStyle(.secondary).lineLimit(2)
                        }.frame(width: 100, alignment: .leading)
                    }
                }
            }
        }
    }
    private var providerSection: some View {
        VStack(alignment: .leading, spacing: spacingSmall) {
            Text("Where to Watch").font(.title3.bold())
            providerRow("Stream", providers.flatrate ?? [])
            providerRow("Rent", providers.rent ?? [])
            providerRow("Buy", providers.buy ?? [])
            Text("Streaming data from JustWatch").font(.caption2).foregroundStyle(.secondary)
        }
    }
    @ViewBuilder private func providerRow(_ title: String, _ items: [WatchProvider]) -> some View {
        if !items.isEmpty {
            VStack(alignment: .leading, spacing: 5) {
                Text(title).font(.subheadline.bold())
                ScrollView(.horizontal, showsIndicators: false) { HStack {
                    ForEach(items) { item in HStack { if let url = logoURL(item) { AsyncImage(url: url) { $0.resizable() } placeholder: { Image(systemName: "play.tv") }.frame(width: 28, height: 28).clipShape(RoundedRectangle(cornerRadius: 5)) }; Text(item.providerName).font(.caption) }.padding(.trailing, 8) }
                } }
            }
        }
    }
    private var recommendationsSection: some View {
        VStack(alignment: .leading, spacing: spacingSmall) {
            Text("More Like This").font(.title3.bold())
            ScrollView(.horizontal, showsIndicators: false) { HStack(alignment: .top, spacing: spacingMedium) { ForEach(details.recommendations.results) { movie in NavigationLink(value: movie) { MovieCardView(movie: movie).frame(width: 140) }.buttonStyle(.plain) } } }
        }
    }
}
