import SwiftUI
import MapKit

enum CinemaMapPlacement: Equatable { case tab, sheet }

struct CinemaMapView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var viewModel: CinemaMapViewModel
    let findRoute: CinemaRouteFinder
    let placement: CinemaMapPlacement
    @State private var cameraPosition: MapCameraPosition
    @State private var selectedCinemaId: String?
    init(viewModel: CinemaMapViewModel, findRoute: @escaping CinemaRouteFinder, placement: CinemaMapPlacement) {
        _viewModel = State(initialValue: viewModel); self.findRoute = findRoute; self.placement = placement
        _cameraPosition = State(initialValue: .region(wroclawMapRegion))
    }
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Map(position: $cameraPosition, selection: $selectedCinemaId) {
                    UserAnnotation()
                    ForEach(viewModel.cinemas) { cinema in Marker(cinema.name, systemImage: "popcorn.fill", coordinate: cinemaCoordinate(cinema)).tag(cinema.id) }
                }
                .mapStyle(.standard(elevation: .realistic, pointsOfInterest: .excludingAll))
                .mapControls { MapUserLocationButton(); MapCompass() }
                .frame(height: 330)
                if viewModel.isLocationUnavailable { Label("Turn on location to see distances and routes.", systemImage: "location.slash").font(.footnote).foregroundStyle(.secondary).padding(.vertical, 8) }
                List(viewModel.cinemas) { cinema in
                    HStack {
                        Button { viewModel.toggleCinema(cinema.id); selectedCinemaId = cinema.id; cameraPosition = .region(regionMoved(wroclawMapRegion, to: cinemaCoordinate(cinema))) } label: {
                            VStack(alignment: .leading, spacing: 3) {
                                Text(cinema.name).font(.headline).foregroundStyle(.primary)
                                Text(cinema.address).font(.caption).foregroundStyle(.secondary)
                                if !formattedDistance(cinema.distanceInMeters).isEmpty { Text(formattedDistance(cinema.distanceInMeters)).font(.caption2).foregroundStyle(.secondary) }
                            }
                        }.buttonStyle(.plain)
                        Spacer()
                        NavigationLink(value: cinema) { Image(systemName: "info.circle") }.accessibilityLabel("Cinema details")
                    }
                }.listStyle(.plain)
            }
            .navigationTitle("Cinemas")
            .toolbar { if placement == .sheet { ToolbarItem(placement: .topBarTrailing) { Button("Done") { dismiss() } } } }
            .navigationDestination(for: Cinema.self) { cinema in CinemaDetailView(viewModel: CinemaDetailViewModel(cinema: cinema, userLocation: viewModel.userLocation, findRoute: findRoute)) }
            .task { await viewModel.locateUserIfNeeded() }
            .onChange(of: selectedCinemaId) { _, value in if let value, let cinema = viewModel.cinemas.first(where: { $0.id == value }) { cameraPosition = .region(regionMoved(wroclawMapRegion, to: cinemaCoordinate(cinema))) } }
        }
    }
}
