import Foundation
import Observation

@Observable final class AccountViewModel {
    var email = ""
    var password = ""
    private(set) var signedInEmail: String
    private(set) var state = LoadState.idle
    private(set) var errorMessage = ""
    private(set) var isWaitingForEmailConfirmation = false
    private(set) var syncState = LoadState.idle
    private(set) var syncErrorMessage = ""
    private let account: AccountService
    private let syncAction: () async throws -> Void
    private let clearAction: @MainActor () -> Void
    private var isSyncing = false
    private var syncRequestedAgain = false

    init(account: AccountService, syncSavedMovies: @escaping () async throws -> Void, clearSavedMovies: @escaping @MainActor () -> Void) {
        self.account = account
        self.syncAction = syncSavedMovies
        self.clearAction = clearSavedMovies
        self.signedInEmail = account.signedInEmail()
    }
    var isSignedIn: Bool { !signedInEmail.isEmpty }
    var canSignIn: Bool { !email.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && !password.isEmpty && state != .loading }
    var canSignUp: Bool { canSignIn && password.count >= minimumPasswordLength }
    func signIn() async { guard canSignIn else { return }; await submit(account.signIn) }
    func signUp() async { guard canSignUp else { return }; await submit(account.signUp) }
    private func submit(_ request: AccountRequest) async {
        guard canSignIn else { return }
        state = .loading; errorMessage = ""; isWaitingForEmailConfirmation = false
        do {
            let result = try await request(email.trimmingCharacters(in: .whitespacesAndNewlines), password)
            password = ""
            if result.isEmpty { isWaitingForEmailConfirmation = true; state = .idle }
            else { signedInEmail = result; state = .loaded; await syncSavedMovies() }
        } catch { errorMessage = error.localizedDescription; state = .failed }
    }
    func syncSavedMovies() async {
        guard isSignedIn else { return }
        if isSyncing { syncRequestedAgain = true; return }
        isSyncing = true; syncState = .loading
        repeat {
            syncRequestedAgain = false
            do { try await syncAction(); syncState = .loaded; syncErrorMessage = "" }
            catch { syncState = .failed; syncErrorMessage = error.localizedDescription }
        } while syncRequestedAgain
        isSyncing = false
    }
    func signOut() async {
        if isSignedIn { await syncSavedMovies() }
        try? await account.signOut()
        signedInEmail = ""
        clearAction()
        syncState = .idle
    }
}

func previewAccountViewModel(signedInEmail: String = "test@test.test") -> AccountViewModel {
    let service = AccountService(signedInEmail: { signedInEmail }, signIn: { email, _ in email }, signUp: { email, _ in email }, signOut: {})
    return AccountViewModel(account: service, syncSavedMovies: {}, clearSavedMovies: {})
}
