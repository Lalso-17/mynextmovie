import Foundation
import Observation

@Observable final class CinemaDetailViewModel {
    let cinema: Cinema
    let userLocation: UserLocation
    var travelMode = TravelMode.walking
    private(set) var route = noRoute
    private(set) var routeState = LoadState.idle
    private(set) var errorMessage = ""
    private let findRoute: CinemaRouteFinder
    init(cinema: Cinema, userLocation: UserLocation, findRoute: @escaping CinemaRouteFinder) {
        self.cinema = cinema; self.userLocation = userLocation; self.findRoute = findRoute
    }
    var canFindRoute: Bool { userLocation.isKnown }
    func loadRoute() async {
        guard canFindRoute else { routeState = .failed; errorMessage = "Turn on location to see directions."; return }
        routeState = .loading
        do { route = try await findRoute(userLocation, cinema, travelMode); routeState = .loaded }
        catch { errorMessage = error.localizedDescription; routeState = .failed }
    }
    func formattedTravelTime(_ seconds: TimeInterval) -> String { "\(max(1, Int((seconds / 60).rounded()))) min" }
    func routeSummary(_ route: CinemaRoute) -> String { "\(formattedTravelTime(route.expectedTravelTime)) · \(formattedDistance(route.distance))" }
}
