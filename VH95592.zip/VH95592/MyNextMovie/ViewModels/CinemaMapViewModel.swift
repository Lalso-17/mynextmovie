import Foundation
import Observation

@Observable final class CinemaMapViewModel {
    private(set) var cinemas: [Cinema]
    private(set) var userLocation: UserLocation
    private(set) var hasAskedForLocation = false
    var selectedCinemaId = noCinemaSelected
    var visibleRegion = wroclawMapRegion
    private let findUserLocation: UserLocationFinder
    private let lastKnownLocation: LastKnownLocationReader
    init(cinemas: [Cinema], findUserLocation: @escaping UserLocationFinder, lastKnownLocation: @escaping LastKnownLocationReader = { fallbackUserLocation }) {
        self.cinemas = cinemas.sorted { $0.name < $1.name }
        self.findUserLocation = findUserLocation
        self.lastKnownLocation = lastKnownLocation
        self.userLocation = lastKnownLocation()
        if self.userLocation.isKnown { self.cinemas = cinemasSortedByDistance(cinemas, from: self.userLocation) }
    }
    var isLocationUnavailable: Bool { hasAskedForLocation && !userLocation.isKnown }
    func locateUser() async {
        hasAskedForLocation = true
        let last = lastKnownLocation()
        if last.isKnown { userLocation = last; cinemas = cinemasSortedByDistance(cinemas, from: last) }
        let fresh = await findUserLocation()
        if fresh.isKnown || !userLocation.isKnown {
            userLocation = fresh
            cinemas = fresh.isKnown ? cinemasSortedByDistance(cinemas, from: fresh) : cinemas.sorted { $0.name < $1.name }
        }
    }
    func locateUserIfNeeded() async { if !hasAskedForLocation { await locateUser() } }
    func toggleCinema(_ cinemaId: String) { selectedCinemaId = selectedCinemaId == cinemaId ? noCinemaSelected : cinemaId }
}
