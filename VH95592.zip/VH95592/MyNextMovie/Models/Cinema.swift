import CoreLocation
import Foundation

// Lab 6: the data types of the Cinemas tab are ready.
// Write the other constants and the functions from task 1 in this file.

/// Distance of a cinema before the app knows where the user is.
nonisolated let unknownDistance: CLLocationDistance = -1

/// A cinema in Wrocław, a plain struct,
/// so the views and tests do not depend on `MKMapItem`.
nonisolated struct Cinema: Identifiable, Hashable {
    let id: String
    let name: String
    let address: String  // empty when unknown
    let phoneNumber: String  // empty when unknown
    let website: String  // empty when unknown
    let latitude: CLLocationDegrees
    let longitude: CLLocationDegrees
    var distanceInMeters = unknownDistance
}

/// Where the user is. `isKnown` is false when the app does not know it.
nonisolated struct UserLocation: Equatable {
    let latitude: CLLocationDegrees
    let longitude: CLLocationDegrees
    let isKnown: Bool
}

let noCinemaSelected = ""
let cinemaNotFound = -1
let fallbackCoordinate = CLLocationCoordinate2D(latitude: 51.1100, longitude: 17.0320)
let fallbackUserLocation = UserLocation(latitude: fallbackCoordinate.latitude, longitude: fallbackCoordinate.longitude, isKnown: false)
func cinemaCoordinate(_ cinema: Cinema) -> CLLocationCoordinate2D { CLLocationCoordinate2D(latitude: cinema.latitude, longitude: cinema.longitude) }
func userCoordinate(_ location: UserLocation) -> CLLocationCoordinate2D { CLLocationCoordinate2D(latitude: location.latitude, longitude: location.longitude) }
func distanceInMeters(from: UserLocation, to: Cinema) -> CLLocationDistance { CLLocation(latitude: from.latitude, longitude: from.longitude).distance(from: CLLocation(latitude: to.latitude, longitude: to.longitude)) }
func cinemasSortedByDistance(_ cinemas: [Cinema], from location: UserLocation) -> [Cinema] {
    cinemas.map { cinema in var copy = cinema; copy.distanceInMeters = location.isKnown ? distanceInMeters(from: location, to: cinema) : unknownDistance; return copy }.sorted(by: isCloser)
}
func isCloser(_ first: Cinema, _ second: Cinema) -> Bool {
    if first.distanceInMeters == second.distanceInMeters { return first.name < second.name }
    if first.distanceInMeters == unknownDistance { return false }
    if second.distanceInMeters == unknownDistance { return true }
    return first.distanceInMeters < second.distanceInMeters
}
func positionOfCinema(_ cinemas: [Cinema], cinemaId: String) -> Int { cinemas.firstIndex(where: { $0.id == cinemaId }) ?? cinemaNotFound }
func containsCinema(_ cinemas: [Cinema], cinemaId: String) -> Bool { positionOfCinema(cinemas, cinemaId: cinemaId) != cinemaNotFound }
func formattedDistance(_ distance: CLLocationDistance) -> String {
    guard distance != unknownDistance else { return "" }
    if distance < 1000 { return "\(Int(distance.rounded())) m" }
    return String(format: "%.1f km", distance / 1000)
}
func phoneURL(_ cinema: Cinema) -> URL? {
    let cleaned = cinema.phoneNumber.filter { $0.isNumber || $0 == "+" }
    return cleaned.isEmpty ? nil : URL(string: "tel:\(cleaned)")
}
func hasPhoneNumber(_ cinema: Cinema) -> Bool { phoneURL(cinema) != nil }
func websiteURL(_ cinema: Cinema) -> URL? { URL(string: cinema.website) }
func hasWebsite(_ cinema: Cinema) -> Bool { websiteURL(cinema) != nil && !cinema.website.isEmpty }
