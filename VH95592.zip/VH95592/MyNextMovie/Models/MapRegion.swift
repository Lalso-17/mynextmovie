import MapKit

let wroclawMapRegion = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 51.0956, longitude: 17.0230), latitudinalMeters: 15500, longitudinalMeters: 14000)
func regionMoved(_ region: MKCoordinateRegion, to coordinate: CLLocationCoordinate2D) -> MKCoordinateRegion {
    MKCoordinateRegion(center: coordinate, latitudinalMeters: region.span.latitudeDelta * 111_000, longitudinalMeters: region.span.longitudeDelta * 70_000)
}
func isInRegion(_ coordinate: CLLocationCoordinate2D, _ region: MKCoordinateRegion) -> Bool {
    abs(coordinate.latitude - region.center.latitude) <= region.span.latitudeDelta / 2 && abs(coordinate.longitude - region.center.longitude) <= region.span.longitudeDelta / 2
}
