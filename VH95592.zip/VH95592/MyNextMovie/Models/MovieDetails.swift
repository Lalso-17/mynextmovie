import Foundation

nonisolated struct MovieDetails: Decodable {
    let id: Int
    let tagline: String
    let runtime: Int?
    let credits: Credits
    let videos: VideoList
    let releaseDates: ReleaseDateList
    let watchProviders: WatchProviderList
    let recommendations: TMDBMoviePage
    enum CodingKeys: String, CodingKey {
        case id, tagline, runtime, credits, videos, releaseDates, recommendations
        case watchProviders = "watch/providers"
    }
}
nonisolated struct Credits: Decodable { let cast: [CastMember]; let crew: [CrewMember] }
nonisolated struct CastMember: Decodable, Identifiable { let id: Int; let name: String; let character: String; let profilePath: String? }
nonisolated struct CrewMember: Decodable { let id: Int; let name: String; let job: String }
nonisolated struct VideoList: Decodable { let results: [Video] }
nonisolated struct Video: Decodable { let key: String; let site: String; let type: String; let official: Bool }
nonisolated struct ReleaseDateList: Decodable { let results: [CountryReleaseDates] }
nonisolated struct CountryReleaseDates: Decodable {
    let countryCode: String
    let releaseDates: [ReleaseDate]
    enum CodingKeys: String, CodingKey { case countryCode = "iso31661"; case releaseDates }
}
nonisolated struct ReleaseDate: Decodable { let certification: String; let releaseDate: String; let type: Int }
nonisolated struct WatchProviderList: Decodable { let results: [String: CountryWatchProviders] }
nonisolated struct CountryWatchProviders: Decodable {
    let link: String?
    let flatrate: [WatchProvider]?
    let rent: [WatchProvider]?
    let buy: [WatchProvider]?
}
nonisolated struct WatchProvider: Decodable, Identifiable {
    let providerId: Int
    let providerName: String
    let logoPath: String?
    var id: Int { providerId }
}

let noWatchProviders = CountryWatchProviders(link: nil, flatrate: nil, rent: nil, buy: nil)
let emptyMovieDetails = MovieDetails(id: 0, tagline: "", runtime: nil, credits: Credits(cast: [], crew: []), videos: VideoList(results: []), releaseDates: ReleaseDateList(results: []), watchProviders: WatchProviderList(results: [:]), recommendations: TMDBMoviePage(results: []))
let watchRegionCode = Locale.current.region?.identifier ?? "PL"

func formattedRuntime(_ details: MovieDetails) -> String {
    guard let runtime = details.runtime, runtime > 0 else { return "" }
    let hours = runtime / 60, minutes = runtime % 60
    return hours > 0 ? "\(hours)h \(minutes)m" : "\(minutes)m"
}
func directorNames(_ details: MovieDetails) -> String {
    var names: [String] = []
    for person in details.credits.crew where person.job == "Director" && !names.contains(person.name) { names.append(person.name) }
    return names.joined(separator: ", ")
}
func ageCertification(_ details: MovieDetails, regionCode: String) -> String {
    guard let country = details.releaseDates.results.first(where: { $0.countryCode == regionCode }) else { return "" }
    return country.releaseDates.first(where: { !$0.certification.isEmpty })?.certification ?? ""
}
func trailerKey(_ details: MovieDetails) -> String {
    let trailers = details.videos.results.filter { $0.site == "YouTube" && $0.type == "Trailer" }
    return trailers.first(where: \.official)?.key ?? trailers.first?.key ?? ""
}
func trailerURL(_ details: MovieDetails) -> URL? { let key = trailerKey(details); return key.isEmpty ? nil : URL(string: "https://www.youtube.com/watch?v=\(key)") }
func hasTrailer(_ details: MovieDetails) -> Bool { trailerURL(details) != nil }
func movieFactsLine(_ movie: Movie, _ details: MovieDetails, regionCode: String) -> String {
    [yearAndRating(movie), formattedRuntime(details), ageCertification(details, regionCode: regionCode)].filter { !$0.isEmpty }.joined(separator: textSeparator)
}
func watchProviders(_ details: MovieDetails, regionCode: String) -> CountryWatchProviders { details.watchProviders.results[regionCode] ?? noWatchProviders }
func hasWatchProviders(_ providers: CountryWatchProviders) -> Bool { !(providers.flatrate ?? []).isEmpty || !(providers.rent ?? []).isEmpty || !(providers.buy ?? []).isEmpty }
func profileURL(_ member: CastMember) -> URL? { member.profilePath.flatMap { URL(string: "https://image.tmdb.org/t/p/w185\($0)") } }
func logoURL(_ provider: WatchProvider) -> URL? { provider.logoPath.flatMap { URL(string: "https://image.tmdb.org/t/p/w92\($0)") } }

let releaseTypeTheatricalLimited = 2
let releaseTypeTheatrical = 3
let typicalCinemaRunInDays = 42
func daysSinceReleaseDay(_ releaseDate: String, today: Date) -> Int {
    let day = String(releaseDate.prefix(10))
    let formatter = ISO8601DateFormatter()
    formatter.formatOptions = [.withFullDate]
    guard let date = formatter.date(from: day) else { return -1 }
    let calendar = Calendar(identifier: .gregorian)
    let start = calendar.startOfDay(for: date), end = calendar.startOfDay(for: today)
    let days = calendar.dateComponents([.day], from: start, to: end).day ?? -1
    return days >= 0 ? days : -1
}
func isInCinemas(
    _ details: MovieDetails,
    regionCode: String,
    today: Date
) -> Bool {

    guard let country = details.releaseDates.results.first(
        where: { $0.countryCode == regionCode }
    ) else {
        return false
    }

    return country.releaseDates.contains { release in

        let isTheatrical =
            release.type == releaseTypeTheatrical ||
            release.type == releaseTypeTheatricalLimited

        guard isTheatrical else {
            return false
        }

        let days = daysSinceReleaseDay(
            release.releaseDate,
            today: today
        )

        return days >= 0 && days <= typicalCinemaRunInDays
    }
}

