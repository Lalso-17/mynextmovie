import Foundation
import SwiftData

let maxSearchHistoryCount = 10

func isSavedMovie(_ context: ModelContext, movieId: Int) -> Bool {
    let id = movieId
    var descriptor = FetchDescriptor<SavedMovie>(predicate: #Predicate { $0.movieId == id })
    descriptor.fetchLimit = 1
    return (try? context.fetchCount(descriptor)) ?? 0 > 0
}
func toggleSavedMovie(_ context: ModelContext, _ movie: Movie, now: Date = .now) {
    let id = movie.id
    let descriptor = FetchDescriptor<SavedMovie>(predicate: #Predicate { $0.movieId == id })
    if let saved = try? context.fetch(descriptor).first {
        if saved.isInCloud { context.insert(RemovedSavedMovie(movieId: id)) }
        context.delete(saved)
    } else { context.insert(SavedMovie(movie: movie, savedAt: now)) }
}
func movieFromSaved(_ saved: SavedMovie) -> Movie {
    Movie(id: saved.movieId, title: saved.title, overview: saved.overview, releaseDate: saved.releaseDate, posterPath: saved.posterPath, voteAverage: saved.voteAverage, genreIds: saved.genreIds)
}
func moviesFromSaved(_ saved: [SavedMovie]) -> [Movie] { saved.map(movieFromSaved) }
func clearSavedMovies(_ context: ModelContext) {
    for item in (try? context.fetch(FetchDescriptor<SavedMovie>())) ?? [] { context.delete(item) }
    for item in (try? context.fetch(FetchDescriptor<RemovedSavedMovie>())) ?? [] { context.delete(item) }
}
func recordSearch(_ context: ModelContext, query: String, now: Date = .now) {
    let clean = query.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !clean.isEmpty else { return }
    let descriptor = FetchDescriptor<SearchHistoryEntry>(predicate: #Predicate { $0.query == clean })
    if let old = try? context.fetch(descriptor).first { old.searchedAt = now }
    else { context.insert(SearchHistoryEntry(query: clean, searchedAt: now)) }
    removeOldSearches(context)
}
private func removeOldSearches(_ context: ModelContext) {
    var descriptor = FetchDescriptor<SearchHistoryEntry>(sortBy: [SortDescriptor(\.searchedAt, order: .reverse)])
    descriptor.fetchOffset = maxSearchHistoryCount
    for item in (try? context.fetch(descriptor)) ?? [] { context.delete(item) }
}
func recentSearches(_ context: ModelContext) -> [SearchHistoryEntry] {
    var descriptor = FetchDescriptor<SearchHistoryEntry>(sortBy: [SortDescriptor(\.searchedAt, order: .reverse)])
    descriptor.fetchLimit = maxSearchHistoryCount
    return (try? context.fetch(descriptor)) ?? []
}
func clearSearchHistory(_ context: ModelContext) {
    for item in (try? context.fetch(FetchDescriptor<SearchHistoryEntry>())) ?? [] { context.delete(item) }
}
func storeCachedResponse(_ context: ModelContext, key: String, data: Data, now: Date = .now) {
    let descriptor = FetchDescriptor<CachedResponse>(predicate: #Predicate { $0.key == key })
    if let cached = try? context.fetch(descriptor).first { cached.data = data; cached.fetchedAt = now }
    else { context.insert(CachedResponse(key: key, data: data, fetchedAt: now)) }
}
func cachedResponseData(_ context: ModelContext, key: String) -> Data {
    let descriptor = FetchDescriptor<CachedResponse>(predicate: #Predicate { $0.key == key })
    return (try? context.fetch(descriptor).first?.data) ?? Data()
}
func fetchWithCacheFallback(_ context: ModelContext, key: String, fetch: () async throws -> Data) async throws -> Data {
    do { let data = try await fetch(); storeCachedResponse(context, key: key, data: data); return data }
    catch { let cached = cachedResponseData(context, key: key); if !cached.isEmpty { return cached }; throw error }
}
