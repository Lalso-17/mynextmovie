import Foundation
import SwiftData

func cloudMovieFromSaved(_ saved: SavedMovie) -> CloudSavedMovie {
    CloudSavedMovie(id: saved.movieId, title: saved.title, overview: saved.overview, releaseDate: saved.releaseDate, posterPath: saved.posterPath, voteAverage: saved.voteAverage, genreIds: saved.genreIds, savedAt: saved.savedAt)
}
func movieFromCloud(_ cloud: CloudSavedMovie) -> Movie {
    Movie(id: cloud.id, title: cloud.title, overview: cloud.overview, releaseDate: cloud.releaseDate, posterPath: cloud.posterPath, voteAverage: cloud.voteAverage, genreIds: cloud.genreIds)
}
func syncSavedMovies(_ context: ModelContext, cloud: SavedMoviesCloud) async throws {
    try await removePendingCloudMovies(context, cloud: cloud)
    let remote = try await cloud.fetchMovies()
    mergeCloudMovies(context, remote: remote)
    try await uploadPendingLocalMovies(context, cloud: cloud)
}
private func removePendingCloudMovies(_ context: ModelContext, cloud: SavedMoviesCloud) async throws {
    let pending = (try? context.fetch(FetchDescriptor<RemovedSavedMovie>())) ?? []
    for item in pending {
        let id = item.movieId
        try await cloud.removeMovie(id)
        let descriptor = FetchDescriptor<RemovedSavedMovie>(predicate: #Predicate { $0.movieId == id })
        if let current = try? context.fetch(descriptor).first { context.delete(current) }
    }
}
private func mergeCloudMovies(_ context: ModelContext, remote: [CloudSavedMovie]) {
    let local = (try? context.fetch(FetchDescriptor<SavedMovie>())) ?? []
    let removed = Set((try? context.fetch(FetchDescriptor<RemovedSavedMovie>()))?.map(\.movieId) ?? [])
    let remoteIds = Set(remote.map(\.id))
    for item in local where item.isInCloud && !remoteIds.contains(item.movieId) { context.delete(item) }
    let localIds = Set(local.map(\.movieId))
    for item in remote where !localIds.contains(item.id) && !removed.contains(item.id) {
        context.insert(SavedMovie(movie: movieFromCloud(item), savedAt: item.savedAt, isInCloud: true))
    }
    for item in local where remoteIds.contains(item.movieId) { item.isInCloud = true }
}
private func uploadPendingLocalMovies(_ context: ModelContext, cloud: SavedMoviesCloud) async throws {
    let pending = (try? context.fetch(FetchDescriptor<SavedMovie>()))?.filter { !$0.isInCloud } ?? []
    let ids = pending.map(\.movieId)
    let payload = pending.map(cloudMovieFromSaved)
    try await cloud.uploadMovies(payload)
    for id in ids {
        let descriptor = FetchDescriptor<SavedMovie>(predicate: #Predicate { $0.movieId == id })
        if let current = try? context.fetch(descriptor).first {
            current.isInCloud = true
        } else {
            // The user may have removed the movie while the upload was suspended.
            // The cloud now has it, so queue a remote deletion instead of losing the intent.
            let removedDescriptor = FetchDescriptor<RemovedSavedMovie>(predicate: #Predicate { $0.movieId == id })
            if (try? context.fetch(removedDescriptor).first) == nil {
                context.insert(RemovedSavedMovie(movieId: id))
            }
        }
    }
}
