import SwiftUI
import SwiftData

@main
struct MyNextMovieApp: App {
    var body: some Scene {
        WindowGroup { RootView() }
            .modelContainer(for: storedModelTypes)
    }
}

private struct RootView: View {
    @Environment(\.modelContext) private var modelContext
    @State private var accountViewModel: AccountViewModel?
    var body: some View {
        Group {
            if let accountViewModel {
                if accountViewModel.isSignedIn { AppTabs(account: accountViewModel) }
                else { SignInView(viewModel: accountViewModel) }
            } else { ProgressView() }
        }
        .task {
            guard accountViewModel == nil else { return }
            let context = modelContext
            let viewModel = AccountViewModel(
                account: supabaseAccountService,
                syncSavedMovies: { try await syncSavedMovies(context, cloud: supabaseSavedMoviesCloud) },
                clearSavedMovies: { clearSavedMovies(context) }
            )
            #if DEBUG
            if !viewModel.isSignedIn { viewModel.email = testAccountEmail; viewModel.password = testAccountPassword }
            #endif
            accountViewModel = viewModel
        }
    }
}

private struct AppTabs: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.scenePhase) private var scenePhase
    @Bindable var account: AccountViewModel
    @Query(filter: #Predicate<SavedMovie> { !$0.isInCloud }) private var pendingSaved: [SavedMovie]
    @Query private var pendingRemoved: [RemovedSavedMovie]
    private var pendingCount: Int { pendingSaved.count + pendingRemoved.count }
    private var movieLoader: MovieLoader { { try await loadPopularMovies(cache: modelContext) } }
    private var detailsLoader: MovieDetailsLoader { { id in try await loadTMDBMovieDetails(movieId: id, cache: modelContext) } }
    var body: some View {
        TabView {
            Tab("Movies", systemImage: symbolNameMovies) {
                MovieListView(viewModel: MovieListViewModel(loadMovies: movieLoader), loadDetails: detailsLoader)
            }
            Tab("Saved", systemImage: "bookmark") { SavedMoviesView(loadDetails: detailsLoader) }
            Tab("Cinemas", systemImage: symbolNameCinema) {
                let model = CinemaMapViewModel(cinemas: wroclawCinemas, findUserLocation: findUserLocation, lastKnownLocation: lastKnownUserLocation)
                CinemaMapView(viewModel: model, findRoute: findMapKitRoute, placement: .tab)
            }
            Tab("Account", systemImage: "person.crop.circle") { NavigationStack { AccountView(viewModel: account) } }
            Tab("Search", systemImage: symbolNameSearch, role: .search) {
                SearchView(viewModel: SearchViewModel(searchMovies: searchTMDBMovies), loadDetails: detailsLoader)
            }
        }
        .task { await account.syncSavedMovies() }
        .onChange(of: scenePhase) { _, phase in if phase == .active { Task { await account.syncSavedMovies() } } }
        .onChange(of: pendingCount) { oldValue, newValue in if newValue > oldValue { Task { await account.syncSavedMovies() } } }
    }
}
