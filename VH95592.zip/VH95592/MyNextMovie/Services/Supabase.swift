import Foundation
import Supabase

let savedMoviesTable = "saved_movies"
let savedMoviesIdColumn = "id"
let savedMoviesSavedAtColumn = "saved_at"
let savedMoviesConflictKey = "user_id,id"
let minimumPasswordLength = 6
let testAccountEmail = "test@test.test"
let testAccountPassword = "test"

struct SupabaseError: LocalizedError { let message: String; var errorDescription: String? { message } }

nonisolated struct CloudSavedMovie: Codable, Equatable {
    let id: Int
    let title: String
    let overview: String
    let releaseDate: String
    let posterPath: String?
    let voteAverage: Double
    let genreIds: [Int]
    let savedAt: Date
    enum CodingKeys: String, CodingKey {
        case id, title, overview, savedAt = "saved_at"
        case releaseDate = "release_date", posterPath = "poster_path"
        case voteAverage = "vote_average", genreIds = "genre_ids"
    }
}

private var sharedSupabaseClient: SupabaseClient?
private func requireSupabaseClient() throws -> SupabaseClient {
    if let sharedSupabaseClient { return sharedSupabaseClient }
    guard let url = URL(string: supabaseURL()), !supabaseAnonKey().isEmpty else {
        throw SupabaseError(message: "Missing Supabase keys. Add them to Config/Secrets.xcconfig.")
    }
    let client = SupabaseClient(supabaseURL: url, supabaseKey: supabaseAnonKey())
    sharedSupabaseClient = client
    return client
}

@MainActor func supabaseSignedInEmail() -> String {
    guard let client = try? requireSupabaseClient() else { return "" }
    return client.auth.currentUser?.email ?? ""
}
func signInToSupabase(email: String, password: String) async throws -> String {
    let client = try requireSupabaseClient()
    let session = try await client.auth.signIn(email: email, password: password)
    return session.user.email ?? email
}
func signUpToSupabase(email: String, password: String) async throws -> String {
    let client = try requireSupabaseClient()
    let response = try await client.auth.signUp(email: email, password: password)
    return response.session?.user.email ?? ""
}
func signOutOfSupabase() async throws {
    guard let client = try? requireSupabaseClient() else { return }
    try? await client.auth.signOut()
}
func fetchCloudSavedMovies() async throws -> [CloudSavedMovie] {
    let client = try requireSupabaseClient()
    return try await client.from(savedMoviesTable).select().order(savedMoviesSavedAtColumn, ascending: false).execute().value
}
func uploadCloudSavedMovies(_ movies: [CloudSavedMovie]) async throws {
    guard !movies.isEmpty else { return }
    let client = try requireSupabaseClient()
    try await client.from(savedMoviesTable).upsert(movies, onConflict: savedMoviesConflictKey, ignoreDuplicates: true).execute()
}
func removeCloudSavedMovie(movieId: Int) async throws {
    let client = try requireSupabaseClient()
    try await client.from(savedMoviesTable).delete().eq(savedMoviesIdColumn, value: movieId).execute()
}
let supabaseAccountService = AccountService(signedInEmail: supabaseSignedInEmail, signIn: signInToSupabase, signUp: signUpToSupabase, signOut: signOutOfSupabase)
let supabaseSavedMoviesCloud = SavedMoviesCloud(fetchMovies: fetchCloudSavedMovies, uploadMovies: uploadCloudSavedMovies, removeMovie: removeCloudSavedMovie)
