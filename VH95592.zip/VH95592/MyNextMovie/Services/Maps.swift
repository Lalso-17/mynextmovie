import MapKit
import CoreLocation

typealias UserLocationFinder = () async -> UserLocation
typealias LastKnownLocationReader = () -> UserLocation
enum TravelMode: Hashable { case walking, driving }
struct CinemaRoute {
    let polyline: MKPolyline
    let distance: CLLocationDistance
    let expectedTravelTime: TimeInterval
}
let noRoute = CinemaRoute(polyline: MKPolyline(), distance: 0, expectedTravelTime: 0)
struct NoRouteFound: LocalizedError { var errorDescription: String? { "Maps found no way to this cinema." } }
typealias CinemaRouteFinder = (UserLocation, Cinema, TravelMode) async throws -> CinemaRoute
func transportTypeForMapKit(_ mode: TravelMode) -> MKDirectionsTransportType { mode == .walking ? .walking : .automobile }
func mapItemForCinema(_ cinema: Cinema) -> MKMapItem {
    let coordinate = cinemaCoordinate(cinema)

    let item = MKMapItem(
        location: CLLocation(
            latitude: coordinate.latitude,
            longitude: coordinate.longitude
        ),
        address: nil
    )

    item.name = cinema.name
    return item
}
func findMapKitRoute(userLocation: UserLocation, cinema: Cinema, travelMode: TravelMode) async throws -> CinemaRoute {
    let request = MKDirections.Request()
    request.source = MKMapItem(
        location: CLLocation(
            latitude: userLocation.latitude,
            longitude: userLocation.longitude
        ),
        address: nil
    )
    request.destination = mapItemForCinema(cinema)
    request.transportType = transportTypeForMapKit(travelMode)
    let response = try await MKDirections(request: request).calculate()
    guard let route = response.routes.first else { throw NoRouteFound() }
    return CinemaRoute(polyline: route.polyline, distance: route.distance, expectedTravelTime: route.expectedTravelTime)
}
func openCinemaInMaps(_ cinema: Cinema, travelMode: TravelMode) {
    let item = mapItemForCinema(cinema)
    item.openInMaps(launchOptions: [MKLaunchOptionsDirectionsModeKey: travelMode == .walking ? MKLaunchOptionsDirectionsModeWalking : MKLaunchOptionsDirectionsModeDriving])
}

func findLookAroundScene(_ cinema: Cinema) async -> MKLookAroundScene? {
    let request = MKLookAroundSceneRequest(coordinate: cinemaCoordinate(cinema))
    return try? await request.scene
}
