import Foundation
import SwiftData

private let tmdbScheme = "https"
private let tmdbHost = "api.themoviedb.org"
private let tmdbPopularPath = "/3/movie/popular"
private let tmdbSearchPath = "/3/search/movie"
private let tmdbDiscoverPath = "/3/discover/movie"
private let tmdbAPIKeyParameter = "api_key"
private let tmdbQueryParameter = "query"
private let tmdbGenreParameter = "with_genres"
private let tmdbAppendParameter = "append_to_response"
private let httpStatusOK = 200
private let httpStatusUnauthorized = 401
private let detailsAppendParts = "credits,videos,release_dates,watch/providers,recommendations"

nonisolated struct TMDBMoviePage: Decodable { let results: [Movie] }

struct TMDBError: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

func tmdbURL(path: String, parameters: [URLQueryItem], apiKey: String) -> URL? {
    var components = URLComponents()
    components.scheme = tmdbScheme
    components.host = tmdbHost
    components.path = path
    components.queryItems = [URLQueryItem(name: tmdbAPIKeyParameter, value: apiKey)] + parameters
    return components.url
}

func tmdbPopularURL(apiKey: String) -> URL? {
    tmdbURL(path: tmdbPopularPath, parameters: [], apiKey: apiKey)
}

func tmdbSearchURL(query: String, genreId: Int, apiKey: String) -> URL? {
    let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
    if !trimmed.isEmpty {
        return tmdbURL(path: tmdbSearchPath, parameters: [URLQueryItem(name: tmdbQueryParameter, value: trimmed)], apiKey: apiKey)
    }
    if genreId != noGenreId {
        return tmdbURL(path: tmdbDiscoverPath, parameters: [URLQueryItem(name: tmdbGenreParameter, value: String(genreId))], apiKey: apiKey)
    }
    return tmdbURL(path: tmdbDiscoverPath, parameters: [], apiKey: apiKey)
}

func tmdbMovieDetailsURL(movieId: Int, apiKey: String) -> URL? {
    tmdbURL(path: "/3/movie/\(movieId)", parameters: [URLQueryItem(name: tmdbAppendParameter, value: detailsAppendParts)], apiKey: apiKey)
}

func decodeTMDBMovies(_ data: Data) throws -> [Movie] {
    let decoder = JSONDecoder()
    decoder.keyDecodingStrategy = .convertFromSnakeCase
    return try decoder.decode(TMDBMoviePage.self, from: data).results
}

func decodeTMDBMovieDetails(_ data: Data) throws -> MovieDetails {
    let decoder = JSONDecoder()
    decoder.keyDecodingStrategy = .convertFromSnakeCase
    return try decoder.decode(MovieDetails.self, from: data)
}

func checkTMDBResponse(_ response: URLResponse) throws {
    guard let http = response as? HTTPURLResponse else { throw TMDBError(message: "Invalid TMDB response.") }
    if http.statusCode == httpStatusUnauthorized { throw TMDBError(message: "TMDB API key is invalid. Check Config/Secrets.xcconfig.") }
    guard http.statusCode == httpStatusOK else { throw TMDBError(message: "TMDB request failed with HTTP status \(http.statusCode).") }
}

private func fetchTMDBData(_ address: URL?) async throws -> Data {
    guard !tmdbAPIKey().isEmpty else { throw TMDBError(message: "Missing TMDB API key. Add it to Config/Secrets.xcconfig.") }
    guard let address else { throw TMDBError(message: "Could not construct TMDB request URL.") }
    let (data, response) = try await URLSession.shared.data(from: address)
    try checkTMDBResponse(response)
    return data
}

func fetchPopularMovies() async throws -> [Movie] {
    try decodeTMDBMovies(await fetchTMDBData(tmdbPopularURL(apiKey: tmdbAPIKey())))
}

func searchTMDBMovies(query: String, genreId: Int) async throws -> [Movie] {
    let movies = try decodeTMDBMovies(await fetchTMDBData(tmdbSearchURL(query: query, genreId: genreId, apiKey: tmdbAPIKey())))
    if !query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && genreId != noGenreId {
        return filterMovies(movies, query: "", genreId: genreId)
    }
    return movies
}

func fetchMovieDetails(movieId: Int) async throws -> MovieDetails {
    try decodeTMDBMovieDetails(await fetchTMDBData(tmdbMovieDetailsURL(movieId: movieId, apiKey: tmdbAPIKey())))
}

func loadPopularMovies(cache: ModelContext) async throws -> [Movie] {
    let data = try await fetchWithCacheFallback(cache, key: "popular") { try await fetchTMDBData(tmdbPopularURL(apiKey: tmdbAPIKey())) }
    return try decodeTMDBMovies(data)
}

func loadTMDBMovieDetails(movieId: Int, cache: ModelContext) async throws -> MovieDetails {
    let data = try await fetchWithCacheFallback(cache, key: "movie/\(movieId)") { try await fetchTMDBData(tmdbMovieDetailsURL(movieId: movieId, apiKey: tmdbAPIKey())) }
    return try decodeTMDBMovieDetails(data)
}
