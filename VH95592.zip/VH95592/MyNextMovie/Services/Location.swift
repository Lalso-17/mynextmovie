import CoreLocation

func lastKnownUserLocation() -> UserLocation {
    guard let location = CLLocationManager().location else { return fallbackUserLocation }
    return UserLocation(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude, isKnown: true)
}

func findUserLocation() async -> UserLocation {
    await withTaskGroup(of: UserLocation?.self) { group in
        group.addTask {
            let session = CLServiceSession(authorization: .whenInUse)
            defer { session.invalidate() }
            do {
                for try await update in CLLocationUpdate.liveUpdates() {
                    if update.authorizationDenied { return nil }
                    if let location = update.location {
                        return UserLocation(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude, isKnown: true)
                    }
                }
            } catch { return nil }
            return nil
        }
        group.addTask { try? await Task.sleep(for: .seconds(10)); return nil }
        let result = await group.next() ?? nil
        group.cancelAll()
        return result ?? fallbackUserLocation
    }
}
